﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KStypemig.Models.ViewModels
{
    public class AnhchitietphongVaReview
    {
        public List<Review> Reviews { get; set; }
        public List<AnhChiTietPhong> anhChiTietPhongs { get; set; }

    }
}